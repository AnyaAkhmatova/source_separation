from .spexplus_loss import SpexPlusLoss

__all__ = [
    "SpexPlusLoss"
]
