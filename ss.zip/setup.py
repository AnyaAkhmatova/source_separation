from setuptools import setup, find_packages

setup(name='ss', version='0.0', packages=find_packages())